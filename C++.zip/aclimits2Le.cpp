#include <iostream>
using namespace std;
#include <climits>

int main()
{
    int arr[] = {5,3,6};
    int size = sizeof(arr) / sizeof(arr[0]);

    int Largest = INT_MIN;
    int Secondlargest = INT_MIN;

    for (int i = 1; i < size; i++)
    {
            if (arr[i] > Largest)
        {
            Secondlargest = Largest;
            Largest = arr[i];
        }
        else if (arr[i] > Secondlargest )
        {
            Secondlargest = arr[i];
        }
    }
    cout << "The second largest element in the array is: " << Secondlargest << endl;
    /*if(Secondlargest==Largest) {
        cout<<"both are equal"<<endl;
    }
    else if(Secondlargest!=INT_MIN){
        cou
    }*/

    return 0;
}
