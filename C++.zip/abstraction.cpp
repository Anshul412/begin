#include <iostream>
using namespace std;
class car{
    bool Engine=true;

    public:
void drive(){
    if(Engine){
        cout<<"travel"<<endl;
    }
    else{
        cout<<"Not travel"<<endl;
    }
}
};
int main(){
    car c;
        c.drive();
        return 0;
    }


